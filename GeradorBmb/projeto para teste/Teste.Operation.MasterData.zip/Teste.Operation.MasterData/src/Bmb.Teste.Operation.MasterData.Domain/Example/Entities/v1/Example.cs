﻿using Bmb.Core.Domain.Entities;

namespace Bmb.Teste.Operation.MasterData.Domain.Example.Entities.v1;

public class Example : Entity
{
    public string? PropertyOne { get; set; }
    public bool PropertyTwo { get; set; }
}