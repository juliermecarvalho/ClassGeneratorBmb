﻿namespace Bmb.Teste.Operation.MasterData.Domain.Example.Commands.CreateExampleCommand.v1;

public class CreateExampleCommandResult
{
    public int Id { get; set; }
    public string? PropertyOne { get; set; }
    public bool PropertyTwo { get; set; }
}