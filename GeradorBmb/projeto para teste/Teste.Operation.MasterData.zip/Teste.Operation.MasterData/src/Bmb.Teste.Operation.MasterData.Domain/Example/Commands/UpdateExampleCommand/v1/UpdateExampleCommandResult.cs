﻿namespace Bmb.Teste.Operation.MasterData.Domain.Example.Commands.UpdateExampleCommand.v1;

public class UpdateExampleCommandResult
{
    public int Id { get; set; }
    public string? PropertyOne { get; set; }
    public bool PropertyTwo { get; set; }
}