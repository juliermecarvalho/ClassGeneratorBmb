﻿namespace Bmb.Teste.Operation.MasterData.Domain.Example.Queries.ReadOneExampleQuery.v1;

public class ReadOneExampleQueryResult
{
    public int Id { get; set; }
    public bool IsActive { get; set; }
    public string? PropertyOne { get; set; }
    public bool PropertyTwo { get; set; }
}