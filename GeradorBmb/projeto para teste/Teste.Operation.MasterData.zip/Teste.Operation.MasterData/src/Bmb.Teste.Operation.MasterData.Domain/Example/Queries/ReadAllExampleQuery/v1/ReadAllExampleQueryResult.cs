﻿namespace Bmb.Teste.Operation.MasterData.Domain.Example.Queries.ReadAllExampleQuery.v1;

public class ReadAllExampleQueryResult
{
    public int Id { get; set; }
    public bool IsActive { get; set; }
    public string? PropertyOne { get; set; }
    public bool PropertyTwo { get; set; }
}